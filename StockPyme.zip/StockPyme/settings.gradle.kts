pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // 🔥 ESTA ES LA LÍNEA MÁGICA QUE SOLUCIONA TODO EL PROBLEMA:
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "StockPyme"
include(":app")