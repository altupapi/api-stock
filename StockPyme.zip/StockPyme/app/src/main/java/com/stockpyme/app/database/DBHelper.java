package com.stockpyme.app.database;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "stockpyme.db";
    public static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }
    public Cursor getReporte() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT COUNT(*) as totalProductos, " +
                "SUM(cantidad) as totalStock, " +
                "SUM(cantidad * precio) as valorTotal " +
                "FROM productos", null);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE productos(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nombre TEXT," +
                "cantidad INTEGER," +
                "precio REAL)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS productos");
        onCreate(db);
    }

    public Cursor getProductos() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Esto selecciona todos los datos de tu tabla de productos
        return db.rawQuery("SELECT * FROM productos", null);
    }
}