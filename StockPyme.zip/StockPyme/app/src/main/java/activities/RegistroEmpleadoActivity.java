package activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONObject;

public class RegistroEmpleadoActivity extends AppCompatActivity {

    EditText etUsuario, etPassword, etPasswordConfirm;
    Button btnRegistrar, btnVolverLogin;

    // URL de tu servidor apuntando a una nueva ruta de registro de usuarios
    private final String URL_REGISTRO = "https://agropets-stockpyme.onrender.com/api/usuarios";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_empleado);

        etUsuario = findViewById(R.id.etRegUsuario);
        etPassword = findViewById(R.id.etRegPassword);
        etPasswordConfirm = findViewById(R.id.etRegPasswordConfirm);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnVolverLogin = findViewById(R.id.btnVolverLogin);

        btnVolverLogin.setOnClickListener(v -> finish()); // Regresa al Login

        btnRegistrar.setOnClickListener(v -> {
            String usuario = etUsuario.getText().toString().trim();
            String password = etPassword.getText().toString().trim();
            String confirm = etPasswordConfirm.getText().toString().trim();

            if (usuario.isEmpty() || password.isEmpty() || confirm.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!password.equals(confirm)) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                return;
            }

            registrarEmpleadoEnNube(usuario, password);
        });
    }

    private void registrarEmpleadoEnNube(String usuario, String password) {
        JSONObject body = new JSONObject();
        try {
            body.put("usuario", usuario);
            body.put("password", password);
            // ¡EL SECRETO ESTÁ AQUÍ! Forzamos que sea un empleado para que no cree Jefes
            body.put("rol", "Trabajador");
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL_REGISTRO, body,
                response -> {
                    Toast.makeText(this, "✅ Cuenta de empleado creada con éxito", Toast.LENGTH_LONG).show();
                    finish(); // Cierra esta pantalla y lo devuelve al login
                },
                error -> {
                    Toast.makeText(this, "Error al crear la cuenta. Verifica tu conexión.", Toast.LENGTH_SHORT).show();
                }
        );

        Volley.newRequestQueue(this).add(request);
    }
}