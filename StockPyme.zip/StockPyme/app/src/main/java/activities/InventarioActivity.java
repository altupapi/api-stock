package activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class InventarioActivity extends AppCompatActivity {

    ListView listaProductos;
    TextView tvCantProductos;
    EditText etBuscar;

    List<JSONObject> listaOriginal;
    List<JSONObject> listaFiltrada;
    InventarioAdapter inventarioAdapter;

    ChipGroup chipGroupCategorias;
    FloatingActionButton fabAgregarProducto;

    // 🌐 Tus endpoints de Clever Cloud
    private final String URL_API = "https://agropets-stockpyme.onrender.com/api/productos";
    private final String URL_CATEGORIAS = "https://agropets-stockpyme.onrender.com/api/categorias";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventario);

        listaProductos = findViewById(R.id.listaProductos);
        tvCantProductos = findViewById(R.id.tvCantProductos);
        etBuscar = findViewById(R.id.etBuscar);
        chipGroupCategorias = findViewById(R.id.chipGroupCategorias);
        fabAgregarProducto = findViewById(R.id.fabAgregarProducto);

        listaProductos.setDivider(null);
        listaProductos.setDividerHeight(0);

        // 🔄 1. Cargar el inventario de productos
        cargarInventario();

        // 🏷️ 2. Cargar las pestañas de categorías dinámicamente desde Clever Cloud
        cargarCategoriasDinamicas();

        findViewById(R.id.btnVolver).setOnClickListener(v -> finish());

        if (fabAgregarProducto != null) {
            fabAgregarProducto.setOnClickListener(v -> {
                Intent intent = new Intent(InventarioActivity.this, AgregarProductoActivity.class);
                startActivity(intent);
            });
        }

        // 🔍 Buscador Dinámico en tiempo real
        etBuscar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filtrarProductos(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarInventario();
        cargarCategoriasDinamicas(); // Refresca por si añadiste un producto con nueva categoría
        if (etBuscar != null) {
            etBuscar.setText("");
        }
    }

    // 📥 Obtiene la lista única de categorías desde Node.js e infla los Chips
    private void cargarCategoriasDinamicas() {
        if (chipGroupCategorias == null) return;

        JsonArrayRequest requestCategorias = new JsonArrayRequest(
                Request.Method.GET, URL_CATEGORIAS, null,
                response -> {
                    chipGroupCategorias.removeAllViews(); // Limpiamos las viejas (Abarrotes, Snacks...)

                    // 1. Siempre creamos primero el botón "Todos" de forma manual
                    Chip chipTodos = new Chip(this);
                    chipTodos.setText("Todos");
                    chipTodos.setCheckable(true);
                    chipTodos.setChecked(true); // Seleccionado por defecto
                    chipTodos.setOnClickListener(v -> filtrarPorCategoria("Todos"));
                    chipGroupCategorias.addView(chipTodos);

                    // 2. Recorremos las categorías reales traídas de la base de datos (Aves, Cerdos, Gatos...)
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            String nombreCat = response.getString(i);

                            Chip chipDinamico = new Chip(this);
                            chipDinamico.setText(nombreCat);
                            chipDinamico.setCheckable(true);

                            // Al hacer clic, filtramos usando el texto real del chip
                            chipDinamico.setOnClickListener(v -> filtrarPorCategoria(nombreCat));

                            chipGroupCategorias.addView(chipDinamico);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Log.e("API_ERR", "Error cargando categorías: " + error.toString())
        );
        Volley.newRequestQueue(this).add(requestCategorias);
    }

    private void cargarInventario() {
        listaOriginal = new ArrayList<>();
        listaFiltrada = new ArrayList<>();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, URL_API, null,
                response -> {
                    try {
                        if (tvCantProductos != null) {
                            tvCantProductos.setText(response.length() + " productos");
                        }

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject producto = response.getJSONObject(i);
                            listaOriginal.add(producto);
                            listaFiltrada.add(producto);
                        }

                        inventarioAdapter = new InventarioAdapter(this, listaFiltrada);
                        listaProductos.setAdapter(inventarioAdapter);
                        // Busca esta zona en tu cargarInventario() original:
                        inventarioAdapter = new InventarioAdapter(this, listaFiltrada);
                        listaProductos.setAdapter(inventarioAdapter);

                        // 🎯 AGREGA ESTO JUSTO AQUÍ DEBAJO:
                        listaProductos.setOnItemClickListener((parent, view, position, id) -> {
                            JSONObject productoSeleccionado = listaFiltrada.get(position);

                            // Abrimos la pantalla de edición pasándole el JSON del producto completo
                            Intent intent = new Intent(InventarioActivity.this, EditarProductoActivity.class);
                            intent.putExtra("producto", productoSeleccionado.toString());
                            startActivity(intent);
                        });

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error al conectar con el servidor", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void filtrarProductos(String texto) {
        listaFiltrada.clear();
        String query = texto.toLowerCase().trim();

        for (JSONObject prod : listaOriginal) {
            try {
                String nombre = prod.getString("nombre").toLowerCase();
                String categoria = prod.optString("categoria", "General").toLowerCase();

                if (nombre.contains(query) || categoria.contains(query)) {
                    listaFiltrada.add(prod);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (inventarioAdapter != null) {
            inventarioAdapter.notifyDataSetChanged();
        }
    }

    private void filtrarPorCategoria(String categoria) {
        if (listaOriginal == null) return;

        listaFiltrada.clear();

        if (categoria.equals("Todos")) {
            listaFiltrada.addAll(listaOriginal);
        } else {
            for (JSONObject prod : listaOriginal) {
                try {
                    String catProducto = prod.optString("categoria", "General");
                    if (catProducto.equalsIgnoreCase(categoria)) {
                        listaFiltrada.add(prod);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        if (tvCantProductos != null) {
            tvCantProductos.setText(listaFiltrada.size() + " productos");
        }

        if (inventarioAdapter != null) {
            inventarioAdapter.notifyDataSetChanged();
        }
    }
}