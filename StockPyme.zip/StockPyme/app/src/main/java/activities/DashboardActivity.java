package activities;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.stockpyme.app.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DashboardActivity extends AppCompatActivity {
    LinearLayout containerStockProductos;
    TextView tvMontoVentas, tvCantCriticos, tvSubtextCriticos;
    MaterialCardView cardVentas, cardCriticos;
    LinearLayout containerAlertas;
    BottomNavigationView bottomNavigation;

    private final String URL_API = "https://agropets-stockpyme.onrender.com/api/productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard2);

        tvMontoVentas = findViewById(R.id.tvMontoVentas);
        tvCantCriticos = findViewById(R.id.tvCantCriticos);
        tvSubtextCriticos = findViewById(R.id.tvSubtextCriticos);
        cardVentas = findViewById(R.id.cardVentas);
        cardCriticos = findViewById(R.id.cardCriticos);

        // Contenedores dinámicos
        containerAlertas = findViewById(R.id.containerAlertas);
        containerStockProductos = findViewById(R.id.containerStockProductos); // ¡ENLAZADO CORRECTAMENTE AQUÍ!
        bottomNavigation = findViewById(R.id.bottomNavigation);

        bottomNavigation.setSelectedItemId(R.id.nav_inicio);
        cargarReporte();

        // 📊 La tarjeta de Valor Total te lleva al módulo de Reportes/Gráficas
        cardVentas.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ReportesActivity.class);
            startActivity(intent);
        });

        // 🔥 La tarjeta de Artículos Críticos ahora te redirige al Inventario pulido
        cardCriticos.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnVerTodo).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        // 🔄 Configuración del menú inferior para separar los flujos
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_inicio) return true;

            if (id == R.id.nav_inventario) {
                Intent intent = new Intent(DashboardActivity.this, InventarioActivity.class);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_reportes) {
                Intent intent = new Intent(DashboardActivity.this, ReportesActivity.class);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_ventas) {
                Intent intent = new Intent(DashboardActivity.this, VentasActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarReporte();
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_inicio);
        }
    }

    private void cargarReporte() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, URL_API, null,
                response -> {
                    try {
                        // Limpiamos ambos contenedores antes de cargar para evitar duplicados
                        containerAlertas.removeAllViews();
                        if (containerStockProductos != null) {
                            containerStockProductos.removeAllViews();
                        }

                        int articulosCriticos = 0;
                        double valorTotalInventario = 0.0;

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject producto = response.getJSONObject(i);
                            String nombre = producto.getString("nombre");
                            int cantidad = producto.getInt("cantidad");
                            double precio = producto.getDouble("precio");
                            String sku = "SKU: 7750" + (100000 + producto.optInt("id", i));

                            valorTotalInventario += (cantidad * precio);

                            // 1. LLAMADA REAL PARA LA NUEVA SECCIÓN: Muestra el progreso de todos los productos
                            agregarFilaProgresoStock(nombre, cantidad);

                            // 2. FILTRO DE ALERTAS: Si el stock es crítico, lo agregamos arriba
                            if (cantidad <= 5) {
                                articulosCriticos++;
                                agregarTarjetaAlertaDinámica(nombre, cantidad, sku);
                            }
                        }

                        // Actualizar indicadores superiores con el valor calculado
                        tvMontoVentas.setText("S/ " + String.format("%.2f", valorTotalInventario));
                        tvCantCriticos.setText(String.valueOf(articulosCriticos));

                        if (articulosCriticos > 0) {
                            tvSubtextCriticos.setText("Requieren atencion inmediata");
                        } else {
                            tvSubtextCriticos.setText("Todo el stock en orden");

                            // Mensaje amigable si no hay alertas reales
                            TextView tvVacio = new TextView(this);
                            tvVacio.setText("🎉 ¡Excelente! No tienes productos agotados.");
                            tvVacio.setPadding(20, 40, 20, 40);
                            tvVacio.setGravity(android.view.Gravity.CENTER);
                            containerAlertas.addView(tvVacio);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    tvMontoVentas.setText("S/ 0.00");
                    tvCantCriticos.setText("!");
                    tvSubtextCriticos.setText("Sin conexion");
                }
        );

        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void agregarFilaProgresoStock(String nombre, int cantidad) {
        if (containerStockProductos == null) return;

        // Inflamos la fila de forma segura utilizando el diseño item_stock_progreso.xml
        View itemView = getLayoutInflater().inflate(R.layout.item_stock_progreso, containerStockProductos, false);

        TextView tvNombre = itemView.findViewById(R.id.tvNombreProductoProgreso);
        TextView tvValores = itemView.findViewById(R.id.tvValoresStock);
        ProgressBar progressStock = itemView.findViewById(R.id.progressStock);

        tvNombre.setText(nombre);

        // Regla de negocio visual: Stock mínimo sugerido base es 20 como en tu diseño de muestra
        int stockMinimoSugerido = 20;
        tvValores.setText(cantidad + " / " + stockMinimoSugerido);

        // Adaptamos dinámicamente el valor máximo para evitar que productos con mucho stock rompan la barra
        int maxBarra = Math.max(stockMinimoSugerido, cantidad);
        progressStock.setMax(maxBarra);
        progressStock.setProgress(cantidad);

        // 🎨 Cambiar colores de acuerdo al nivel de stock de cada producto
        if (cantidad <= 5) {
            // Alerta: Stock crítico (Color Rojo)
            tvValores.setTextColor(Color.parseColor("#C62828"));
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#C62828")));
            } else {
                progressStock.getProgressDrawable().setColorFilter(Color.parseColor("#C62828"), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        } else {
            // Normal: Stock óptimo (Color Verde corporativo)
            tvValores.setTextColor(Color.parseColor("#1A1A1A"));
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#2E7D32")));
            } else {
                progressStock.getProgressDrawable().setColorFilter(Color.parseColor("#2E7D32"), android.graphics.PorterDuff.Mode.SRC_IN);
            }
        }

        // Insertar la fila procesada dentro de la tarjeta blanca del Dashboard en el hilo de UI
        runOnUiThread(() -> containerStockProductos.addView(itemView));
    }

    private void agregarTarjetaAlertaDinámica(String nombre, int cantidad, String sku) {
        View cardView = getLayoutInflater().inflate(R.layout.item_alerta_stock, containerAlertas, false);

        View indicatorBar = cardView.findViewById(R.id.indicatorBar);
        TextView tvNombreProd = cardView.findViewById(R.id.tvNombreProd);
        TextView tvSkuProd = cardView.findViewById(R.id.tvSkuProd);
        TextView tvCantUnidades = cardView.findViewById(R.id.tvCantUnidades);
        TextView tvBadgeEstado = cardView.findViewById(R.id.tvBadgeEstado);

        tvNombreProd.setText(nombre);
        tvSkuProd.setText(sku);
        tvCantUnidades.setText(cantidad + "\nUNIDADES");

        if (cantidad == 0) {
            indicatorBar.setBackgroundColor(Color.parseColor("#C62828"));
            tvBadgeEstado.setText("Agotado");
            tvBadgeEstado.setTextColor(Color.parseColor("#C62828"));
            tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_rojo);
        } else {
            indicatorBar.setBackgroundColor(Color.parseColor("#EF6C00"));
            tvBadgeEstado.setText("Stock Bajo");
            tvBadgeEstado.setTextColor(Color.parseColor("#E65100"));
            tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_naranja);
        }

        // Al presionar la tarjeta de alerta individual abajo, también te lleva a InventarioActivity
        cardView.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        containerAlertas.addView(cardView);
    }
}