package activities;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.stockpyme.app.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DashboardJefeActivity extends AppCompatActivity {
    LinearLayout containerStockProductos;
    TextView tvMontoVentas, tvCantCriticos, tvSubtextCriticos;
    MaterialCardView cardVentas, cardCriticos;
    LinearLayout containerAlertas;
    BottomNavigationView bottomNavigation;

    private final String URL_API = "https://agropets-stockpyme.onrender.com/api/productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 🌟 Apunta exactamente al mismo layout completo que usaba tu dashboard antiguo
        setContentView(R.layout.activity_dashboard2);

        tvMontoVentas = findViewById(R.id.tvMontoVentas);
        tvCantCriticos = findViewById(R.id.tvCantCriticos);
        tvSubtextCriticos = findViewById(R.id.tvSubtextCriticos);
        cardVentas = findViewById(R.id.cardVentas);
        cardCriticos = findViewById(R.id.cardCriticos);

        containerAlertas = findViewById(R.id.containerAlertas);
        containerStockProductos = findViewById(R.id.containerStockProductos);
        bottomNavigation = findViewById(R.id.bottomNavigation);

        bottomNavigation.setSelectedItemId(R.id.nav_inicio);
        cargarReporte();

        // 📊 Navegación del Jefe a Reportes
        cardVentas.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardJefeActivity.this, ReportesActivity.class);
            startActivity(intent);
        });

        // 🔥 Navegación del Jefe a Inventario
        cardCriticos.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardJefeActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.btnVerTodo).setOnClickListener(v -> {
            Intent intent = new Intent(DashboardJefeActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        // 🔄 Configuración del menú inferior para el Jefe
        bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_inicio) return true;

            if (id == R.id.nav_inventario) {
                Intent intent = new Intent(DashboardJefeActivity.this, InventarioActivity.class);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_reportes) {
                Intent intent = new Intent(DashboardJefeActivity.this, ReportesActivity.class);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_ventas) {
                Intent intent = new Intent(DashboardJefeActivity.this, VentasActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarReporte();
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_inicio);
        }
    }

    private void cargarReporte() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, URL_API, null,
                response -> {
                    try {
                        containerAlertas.removeAllViews();
                        if (containerStockProductos != null) {
                            containerStockProductos.removeAllViews();
                        }

                        int articulosCriticos = 0;
                        double valorTotalInventario = 0.0;

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject producto = response.getJSONObject(i);
                            String nombre = producto.getString("nombre");
                            int cantidad = producto.getInt("cantidad");
                            double precio = producto.getDouble("precio");
                            String sku = "SKU: 7750" + (100000 + producto.optInt("id", i));

                            valorTotalInventario += (cantidad * precio);

                            agregarFilaProgresoStock(nombre, cantidad);

                            if (cantidad <= 5) {
                                articulosCriticos++;
                                agregarTarjetaAlertaDinámica(nombre, cantidad, sku);
                            }
                        }

                        tvMontoVentas.setText("S/ " + String.format("%.2f", valorTotalInventario));
                        tvCantCriticos.setText(String.valueOf(articulosCriticos));

                        if (articulosCriticos > 0) {
                            tvSubtextCriticos.setText("Requieren atencion inmediata");
                        } else {
                            tvSubtextCriticos.setText("Todo el stock en orden");

                            TextView tvVacio = new TextView(this);
                            tvVacio.setText("🎉 ¡Excelente! No tienes productos agotados.");
                            tvVacio.setPadding(20, 40, 20, 40);
                            tvVacio.setGravity(android.view.Gravity.CENTER);
                            containerAlertas.addView(tvVacio);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    tvMontoVentas.setText("S/ 0.00");
                    tvCantCriticos.setText("!");
                    tvSubtextCriticos.setText("Sin conexion");
                }
        );

        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void agregarFilaProgresoStock(String nombre, int cantidad) {
        if (containerStockProductos == null) return;

        View itemView = getLayoutInflater().inflate(R.layout.item_stock_progreso, containerStockProductos, false);

        TextView tvNombre = itemView.findViewById(R.id.tvNombreProductoProgreso);
        TextView tvValores = itemView.findViewById(R.id.tvValoresStock);
        ProgressBar progressStock = itemView.findViewById(R.id.progressStock);

        tvNombre.setText(nombre);

        int stockMinimoSugerido = 20;
        tvValores.setText(cantidad + " / " + stockMinimoSugerido);

        int maxBarra = Math.max(stockMinimoSugerido, cantidad);
        progressStock.setMax(maxBarra);
        progressStock.setProgress(cantidad);

        if (cantidad <= 5) {
            tvValores.setTextColor(Color.parseColor("#C62828"));
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#C62828")));
            }
        } else {
            tvValores.setTextColor(Color.parseColor("#1A1A1A"));
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#2E7D32")));
            }
        }

        runOnUiThread(() -> containerStockProductos.addView(itemView));
    }

    private void agregarTarjetaAlertaDinámica(String nombre, int cantidad, String sku) {
        View cardView = getLayoutInflater().inflate(R.layout.item_alerta_stock, containerAlertas, false);

        View indicatorBar = cardView.findViewById(R.id.indicatorBar);
        TextView tvNombreProd = cardView.findViewById(R.id.tvNombreProd);
        TextView tvSkuProd = cardView.findViewById(R.id.tvSkuProd);
        TextView tvCantUnidades = cardView.findViewById(R.id.tvCantUnidades);
        TextView tvBadgeEstado = cardView.findViewById(R.id.tvBadgeEstado);

        tvNombreProd.setText(nombre);
        tvSkuProd.setText(sku);
        tvCantUnidades.setText(cantidad + "\nUNIDADES");

        if (cantidad == 0) {
            indicatorBar.setBackgroundColor(Color.parseColor("#C62828"));
            tvBadgeEstado.setText("Agotado");
            tvBadgeEstado.setTextColor(Color.parseColor("#C62828"));
            tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_rojo);
        } else {
            indicatorBar.setBackgroundColor(Color.parseColor("#EF6C00"));
            tvBadgeEstado.setText("Stock Bajo");
            tvBadgeEstado.setTextColor(Color.parseColor("#E65100"));
            tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_naranja);
        }

        cardView.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardJefeActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        containerAlertas.addView(cardView);
    }
}