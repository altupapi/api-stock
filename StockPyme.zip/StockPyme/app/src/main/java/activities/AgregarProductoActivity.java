package activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AgregarProductoActivity extends AppCompatActivity {

    EditText etNombre, etPrecio, etCantidad;
    Spinner spCategoria;
    Button btnGuardar, btnCancelar;

    // 🌐 Rutas de tu backend en Node.js
    private final String URL_API_INSERTAR = "https://agropets-stockpyme.onrender.com/api/productos";
    private final String URL_CATEGORIAS = "https://agropets-stockpyme.onrender.com/api/categorias";

    // Lista dinámica para guardar las categorías de Clever Cloud
    List<String> listaCategorias = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_producto);

        // 1. Mapear componentes visuales
        etNombre = findViewById(R.id.etNombre);
        etPrecio = findViewById(R.id.etPrecio);
        etCantidad = findViewById(R.id.etCantidad);
        spCategoria = findViewById(R.id.spCategoria);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnCancelar = findViewById(R.id.btnCancelar);

        // 🔄 2. Cargar las categorías en tiempo real desde la API
        cargarCategoriasDinamicas();

        // 3. Listeners de interacción
        btnGuardar.setOnClickListener(v -> guardarProductoEnBaseDatos());
        btnCancelar.setOnClickListener(v -> finish());
    }

    // 📥 Método para conectar el Spinner con Clever Cloud de manera dinámica
    private void cargarCategoriasDinamicas() {
        JsonArrayRequest requestCategorias = new JsonArrayRequest(
                Request.Method.GET, URL_CATEGORIAS, null,
                response -> {
                    listaCategorias.clear();

                    // Recorremos las categorías reales recibidas de la base de datos
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            listaCategorias.add(response.getString(i));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    // En caso de que la base de datos esté vacía por algún motivo, dejamos una por defecto
                    if (listaCategorias.isEmpty()) {
                        listaCategorias.add("General");
                    }

                    // Inflamos el Spinner con el adaptador usando la lista dinámica
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_dropdown_item, listaCategorias);
                    spCategoria.setAdapter(adapter);
                },
                error -> {
                    Log.e("API_ERR", "Error al traer categorías: " + error.toString());
                    Toast.makeText(this, "⚠️ No se pudieron cargar las categorías desde el servidor", Toast.LENGTH_SHORT).show();
                }
        );
        Volley.newRequestQueue(this).add(requestCategorias);
    }

    private void guardarProductoEnBaseDatos() {
        String nombre = etNombre.getText().toString().trim();
        String precioStr = etPrecio.getText().toString().trim();
        String cantidadStr = etCantidad.getText().toString().trim();

        // Evitamos errores si el usuario intenta guardar antes de que la API responda
        if (spCategoria.getSelectedItem() == null) {
            Toast.makeText(this, "⚠️ Espera a que carguen las categorías", Toast.LENGTH_SHORT).show();
            return;
        }
        String categoria = spCategoria.getSelectedItem().toString();

        // Validaciones de cajas de texto vacías
        if (nombre.isEmpty() || precioStr.isEmpty() || cantidadStr.isEmpty()) {
            Toast.makeText(this, "⚠️ Por favor, rellena todos los campos vacíos", Toast.LENGTH_SHORT).show();
            return;
        }

        double precio = Double.parseDouble(precioStr);
        int cantidad = Integer.parseInt(cantidadStr);

        // 4. Construcción del JSON Object para enviar en el Body del POST
        JSONObject bodyRequest = new JSONObject();
        try {
            bodyRequest.put("nombre", nombre);
            bodyRequest.put("precio", precio);
            bodyRequest.put("cantidad", cantidad);
            bodyRequest.put("categoria", categoria);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // 5. Envío de petición HTTP POST vía Volley
        JsonObjectRequest postRequest = new JsonObjectRequest(
                Request.Method.POST, URL_API_INSERTAR, bodyRequest,
                response -> {
                    Toast.makeText(this, "🎉 ¡Producto registrado exitosamente!", Toast.LENGTH_SHORT).show();
                    finish(); // Cierra y regresa automáticamente al Inventario
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(this, "❌ Error de conexión al guardar el producto", Toast.LENGTH_SHORT).show();
                }
        );

        Volley.newRequestQueue(this).add(postRequest);
    }
}