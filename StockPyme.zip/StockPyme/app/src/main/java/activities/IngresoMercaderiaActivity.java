package activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R; // 🔥 ESTA LINEA ES CLAVE: Importa el R de tu proyecto

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class IngresoMercaderiaActivity extends AppCompatActivity {

    // 1. Declaración de variables
    private EditText etProveedor, etProductoId, etCantidad;
    private Button btnGuardarCompra;
    private RequestQueue requestQueue;

    // 🌐 Centralizamos tu URL de Render (igual que en Editar)
    private final String BASE_URL = "https://agropets-stockpyme.onrender.com/api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingreso_mercaderia);

        // 2. Enlace con la UI (IDs verificados con tu XML)
        etProveedor = findViewById(R.id.etProveedor);
        etProductoId = findViewById(R.id.etProductoId);
        etCantidad = findViewById(R.id.etCantidadInput);
        btnGuardarCompra = findViewById(R.id.btnGuardarCompra);

        requestQueue = Volley.newRequestQueue(this);

        // 3. Configurar el botón
        btnGuardarCompra.setOnClickListener(v -> procesarEntradaMercaderia());
    }

    private void procesarEntradaMercaderia() {
        String proveedor = etProveedor.getText().toString().trim();
        String productoIdStr = etProductoId.getText().toString().trim();
        String cantidadStr = etCantidad.getText().toString().trim();

        // Validaciones básicas
        if (proveedor.isEmpty() || productoIdStr.isEmpty() || cantidadStr.isEmpty()) {
            Toast.makeText(this, "⚠️ Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validación de cantidad (Evita que la app se cierre con números muy grandes)
        int cantidad;
        try {
            cantidad = Integer.parseInt(cantidadStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "❌ Cantidad no válida", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // 📦 Construcción del JSON para la API (Formato que tu backend ya acepta)
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("proveedor", proveedor);

            JSONArray detallesArray = new JSONArray();
            JSONObject item = new JSONObject();
            item.put("producto_id", productoIdStr);
            item.put("cantidad", cantidad);
            detallesArray.put(item);

            jsonBody.put("detalles", detallesArray);

            String urlPost = BASE_URL + "compras-proveedor";

            // 🚀 Petición POST con el blindaje de Volley
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlPost, jsonBody,
                    response -> {
                        Toast.makeText(this, "🎉 ¡Stock actualizado con éxito!", Toast.LENGTH_LONG).show();
                        finish(); // Cierra esta pantalla y regresa al inventario
                    },
                    error -> {
                        // Volley a veces interpreta respuestas vacías exitosas como errores de parseo
                        if (error.networkResponse != null && (error.networkResponse.statusCode == 200 || error.networkResponse.statusCode == 201)) {
                            Toast.makeText(this, "🎉 ¡Stock actualizado con éxito!", Toast.LENGTH_SHORT).show();
                            finish(); // Cierra esta pantalla y regresa al inventario
                        } else {
                            Log.e("API_ERROR", error.toString());
                            Toast.makeText(this, "❌ Error al conectar con el servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
            );

            requestQueue.add(request);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}