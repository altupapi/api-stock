package activities;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class InventarioAdapter extends ArrayAdapter<JSONObject> {

    private Context context;
    private List<JSONObject> productos;

    public InventarioAdapter(@NonNull Context context, List<JSONObject> productos) {
        super(context, R.layout.item_inventario_card, productos);
        this.context = context;
        this.productos = productos;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_inventario_card, parent, false);
        }

        JSONObject producto = productos.get(position);

        View indicatorBar = convertView.findViewById(R.id.indicatorBar);
        TextView txtNombre = convertView.findViewById(R.id.txtNombre);
        TextView txtCategoriaSku = convertView.findViewById(R.id.txtCategoriaSku);
        TextView txtPrecio = convertView.findViewById(R.id.txtPrecio);
        TextView badgeStock = convertView.findViewById(R.id.badgeStock);

        try {
            String nombre = producto.getString("nombre");
            int stock = producto.getInt("cantidad");
            double precio = producto.getDouble("precio");
            String categoria = producto.optString("categoria", "General");
            String sku = "7750" + (100000 + producto.optInt("id", position));

            txtNombre.setText(nombre);
            txtCategoriaSku.setText(categoria + " • SKU: " + sku);
            txtPrecio.setText("S/ " + String.format("%.2f", precio));

            // 🎨 Lógica de colores premium en base al Stock real
            if (stock == 0) {
                indicatorBar.setBackgroundColor(Color.parseColor("#C62828")); // Rojo
                badgeStock.setText("Agotado (0)");
                badgeStock.setTextColor(Color.parseColor("#C62828"));
                badgeStock.setBackgroundResource(R.drawable.bg_badge_rojo);
            } else if (stock <= 5) {
                indicatorBar.setBackgroundColor(Color.parseColor("#EF6C00")); // Naranja/Amarillo
                badgeStock.setText("Stock Bajo (" + stock + ")");
                badgeStock.setTextColor(Color.parseColor("#E65100"));
                badgeStock.setBackgroundResource(R.drawable.bg_badge_naranja);
            } else {
                indicatorBar.setBackgroundColor(Color.parseColor("#2E7D32")); // Verde
                badgeStock.setText("En Stock (" + stock + ")");
                badgeStock.setTextColor(Color.parseColor("#2E7D32"));
                badgeStock.setBackgroundResource(R.drawable.bg_badge_verde);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }
}