package activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView; // 🌟 IMPORTANTE: Faltaba importar esto
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    EditText etUsuario, etPassword;
    Button btnIngresar;
    TextView tvCrearCuenta;

    // 🌍 TU ENLACE REAL DE RENDER DE INTERNET
    private final String URL_LOGIN = "https://agropets-stockpyme.onrender.com/api/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsuario = findViewById(R.id.etUsuario);
        etPassword = findViewById(R.id.etPassword);
        btnIngresar = findViewById(R.id.btnIngresar);
        tvCrearCuenta = findViewById(R.id.tvCrearCuenta);

        // 🚀 ACCIÓN FALTANTE: Abrir la ventana de registro al hacer clic
        tvCrearCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegistroEmpleadoActivity.class);
                startActivity(intent);
            }
        });

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = etUsuario.getText().toString().trim();
                String clave = etPassword.getText().toString().trim();

                if (!usuario.isEmpty() && !clave.isEmpty()) {
                    ejecutarLogin(usuario, clave);
                } else {
                    Toast.makeText(LoginActivity.this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void ejecutarLogin(String usuario, String password) {
        // Creamos el objeto JSON que el servidor Node.js espera recibir (req.body)
        JSONObject params = new JSONObject();
        try {
            params.put("usuario", usuario);
            params.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Creamos la petición POST mediante Volley
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                URL_LOGIN,
                params,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String mensaje = response.getString("mensaje");

                            if (mensaje.equals("Login exitoso")) {
                                // 🌟 Extraemos el rol devuelto desde Clever Cloud
                                String rol = response.getString("rol");
                                Intent intent;

                                if (rol.equals("jefe")) {
                                    Toast.makeText(LoginActivity.this, "¡Bienvenido Jefe de Agropets!", Toast.LENGTH_SHORT).show();
                                    intent = new Intent(LoginActivity.this, DashboardJefeActivity.class);
                                } else {
                                    Toast.makeText(LoginActivity.this, "¡Bienvenido Colaborador!", Toast.LENGTH_SHORT).show();
                                    intent = new Intent(LoginActivity.this, DashboardTrabajadorActivity.class);
                                }

                                startActivity(intent);
                                finish(); // Cierra el login permanentemente
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(LoginActivity.this, "Error al procesar la respuesta", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Si las credenciales no coinciden devuelve código 401
                        if (error.networkResponse != null && error.networkResponse.statusCode == 401) {
                            Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                        } else {
                            Log.e("LOGIN_ERROR", error.toString());
                            Toast.makeText(LoginActivity.this, "Error de conexión con el servidor", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );

        // Agregamos la petición a la cola de Volley
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(jsonObjectRequest);
    }
}