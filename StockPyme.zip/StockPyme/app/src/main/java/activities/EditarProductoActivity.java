package activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class EditarProductoActivity extends AppCompatActivity {

    EditText etNombre, etPrecio, etCantidad;
    Spinner spCategoria;
    Button btnActualizar, btnCancelar;

    int productoId;
    String categoriaActual;
    List<String> listaCategorias = new ArrayList<>();

    // 🌐 Centralizamos tu URL de Render para que sea la única que use la app
    private final String BASE_URL = "https://agropets-stockpyme.onrender.com/api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_producto);

        etNombre = findViewById(R.id.etEditarNombre);
        etPrecio = findViewById(R.id.etEditarPrecio);
        etCantidad = findViewById(R.id.etEditarCantidad);
        spCategoria = findViewById(R.id.spEditarCategoria);
        btnActualizar = findViewById(R.id.btnActualizar);
        btnCancelar = findViewById(R.id.btnCancelarEdicion);

        // 📦 1. Recorrer y atrapar los datos enviados desde la lista de Inventario
        if (getIntent().hasExtra("producto")) {
            try {
                JSONObject producto = new JSONObject(getIntent().getStringExtra("producto"));
                productoId = producto.getInt("id");
                etNombre.setText(producto.getString("nombre"));
                etPrecio.setText(String.valueOf(producto.getDouble("precio")));
                etCantidad.setText(String.valueOf(producto.getInt("cantidad")));
                categoriaActual = producto.optString("categoria", "General");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // 🏷️ 2. Cargar categorías para que coincidan con Agropets
        cargarCategoriasEdicion();

        btnActualizar.setOnClickListener(v -> enviarActualizacionAClould());
        btnCancelar.setOnClickListener(v -> finish());
    }

    private void cargarCategoriasEdicion() {
        String urlCategorias = BASE_URL + "categorias";

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, urlCategorias, null,
                response -> {
                    listaCategorias.clear();
                    int posicionSeleccionada = 0;

                    for (int i = 0; i < response.length(); i++) {
                        try {
                            String cat = response.getString(i);
                            listaCategorias.add(cat);
                            if (cat.equalsIgnoreCase(categoriaActual)) {
                                posicionSeleccionada = i; // Guardamos su posición para pre-seleccionarla
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, listaCategorias);
                    spCategoria.setAdapter(adapter);
                    spCategoria.setSelection(posicionSeleccionada); // Deja marcada la categoría del producto
                },
                error -> Log.e("API_ERR", error.toString())
        );
        Volley.newRequestQueue(this).add(request);
    }

    private void enviarActualizacionAClould() {
        String nombre = etNombre.getText().toString().trim();
        String precioStr = etPrecio.getText().toString().trim();
        String cantidadStr = etCantidad.getText().toString().trim();
        String categoria = spCategoria.getSelectedItem() != null ? spCategoria.getSelectedItem().toString() : "General";

        if (nombre.isEmpty() || precioStr.isEmpty() || cantidadStr.isEmpty()) {
            Toast.makeText(this, "Rellene todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONObject body = new JSONObject();
        try {
            body.put("nombre", nombre);
            body.put("precio", Double.parseDouble(precioStr));
            body.put("cantidad", Integer.parseInt(cantidadStr));
            body.put("categoria", categoria);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 🚀 AQUI ESTABA EL ERROR: Cambiamos http://10.0.2.2:3000 por tu servidor real en la nube
        String urlPut = BASE_URL + "productos/" + productoId;

        JsonObjectRequest putRequest = new JsonObjectRequest(Request.Method.PUT, urlPut, body,
                response -> {
                    Toast.makeText(this, "🎉 ¡Stock y datos actualizados!", Toast.LENGTH_SHORT).show();
                    finish(); // Regresa al inventario
                },
                error -> {
                    // Volley a veces interpreta respuestas vacías exitosas de PUT como errores de parseo, validamos
                    if (error.networkResponse != null && error.networkResponse.statusCode == 200) {
                        Toast.makeText(this, "🎉 ¡Stock y datos actualizados!", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(this, "Error al sincronizar cambios con el servidor", Toast.LENGTH_SHORT).show();
                        Log.e("VOLLEY_UPDATE_ERR", "Error: " + error.toString());
                    }
                }
        );
        Volley.newRequestQueue(this).add(putRequest);
    }
}