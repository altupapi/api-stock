package activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.card.MaterialCardView;
import com.stockpyme.app.R;

// 📊 LIBRERÍA DE GRÁFICOS MPANDROIDCHART
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.charts.LineChart;

import java.util.ArrayList;

public class ReportesActivity extends AppCompatActivity {

    private TextView tvValorInventario, tvTotalAlmacen, tvVentasHoy, tvVentasMes, tvAlertasCriticas;
    private MaterialCardView cardAlmacenInteractiva;
    private Button btnVolverMenu, btnGenerarAnalisis;
    private LineChart lineChartPrediccion;
    private TextView tvTextoRecomendaciones;
    private BarChart graficoComercial;

    private final String URL_API_RESUMEN = "https://agropets-stockpyme.onrender.com/api/resumen";
    private final String URL_API_ESTADISTICAS = "https://agropets-stockpyme.onrender.com/api/estadisticas-ventas";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportes);

        // 1. Enlace de componentes
        tvValorInventario = findViewById(R.id.tvValorInventario);
        tvTotalAlmacen = findViewById(R.id.tvTotalAlmacen);
        tvVentasHoy = findViewById(R.id.tvVentasHoy);
        tvVentasMes = findViewById(R.id.tvVentasMes);
        tvAlertasCriticas = findViewById(R.id.tvAlertasCriticas);
        cardAlmacenInteractiva = findViewById(R.id.cardAlmacenInteractiva);
        btnVolverMenu = findViewById(R.id.btnVolverMenu);
        btnGenerarAnalisis = findViewById(R.id.btnGenerarAnalisis);
        lineChartPrediccion = findViewById(R.id.lineChartPrediccion);
        tvTextoRecomendaciones = findViewById(R.id.tvTextoRecomendaciones);

        btnGenerarAnalisis.setText("Actualizar Gráficos de Ventas");

        // Estilo inicial
        lineChartPrediccion.setNoDataText("Cargando historial mensual...");
        lineChartPrediccion.setNoDataTextColor(Color.parseColor("#757575"));
        lineChartPrediccion.getDescription().setEnabled(false);
        lineChartPrediccion.getLegend().setEnabled(false);

        // 2. Inyección dinámica del Gráfico Comercial de Barras
        graficoComercial = new BarChart(this);
        try {
            LinearLayout contenedorPrincipal = (LinearLayout) btnVolverMenu.getParent();
            int posicionBoton = contenedorPrincipal.indexOfChild(btnVolverMenu);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 650);
            params.setMargins(0, 16, 0, 32);
            graficoComercial.setLayoutParams(params);
            graficoComercial.setNoDataText("Cargando historial semanal...");

            contenedorPrincipal.addView(graficoComercial, posicionBoton);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 3. Listeners
        btnGenerarAnalisis.setOnClickListener(v -> {
            tvTextoRecomendaciones.setText("Sincronizando historial de caja...");
            cargarDatosGlobales();
        });

        cardAlmacenInteractiva.setOnClickListener(v -> {
            startActivity(new Intent(ReportesActivity.this, InventarioActivity.class));
        });

        btnVolverMenu.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarDatosGlobales();
    }

    private void cargarDatosGlobales() {
        obtenerResumenInventario();
        obtenerEstadisticasReales();
    }

    // ==========================================================
    // 1. CARGA EL INVENTARIO Y LA PROYECTIVIDAD MENSUAL DINÁMICA
    // ==========================================================
    private void obtenerResumenInventario() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL_API_RESUMEN, null,
                response -> {
                    try {
                        double valorInv = response.getDouble("valorInventario");
                        int totalProd = response.getInt("totalProductos");
                        int alertas = response.getInt("stockBajo");

                        // Proyección leída directamente del backend
                        double proyeccion = response.optDouble("gananciasMes", 0.0);

                        // Formateo con Locale.US
                        tvValorInventario.setText(String.format(java.util.Locale.US, "S/ %,.2f", valorInv));
                        tvTotalAlmacen.setText(totalProd + " unds");
                        tvAlertasCriticas.setText(alertas + " productos bajos");

                        if (tvVentasMes != null) {
                            tvVentasMes.setText(String.format(java.util.Locale.US, "S/ %,.2f", proyeccion));
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error cargando inventario", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(request);
    }

    // ==========================================================
    // 2. CARGA LAS VENTAS REALES DE LA CAJA Y GRÁFICOS
    // ==========================================================
    private void obtenerEstadisticasReales() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL_API_ESTADISTICAS, null,
                response -> {
                    try {
                        // 1. Mostrar Ventas de Hoy Reales (Desde el historial de cobros)
                        double ventasHoy = response.optDouble("ventas_hoy_real", 0.0);
                        tvVentasHoy.setText(String.format(java.util.Locale.US, "S/ %,.2f", ventasHoy));

                        // ---------------------------------------------------------
                        // 2. GRÁFICO DE BARRAS: Días de la semana (DATOS REALES DE TU BD)
                        // ---------------------------------------------------------
                        JSONArray arrDias = response.getJSONArray("ventas_por_dias_semana");
                        ArrayList<BarEntry> entradasDias = new ArrayList<>();
                        ArrayList<String> labelsDias = new ArrayList<>();

                        if (arrDias.length() == 0) {
                            tvTextoRecomendaciones.setText("Aún no tienes ventas registradas esta semana. ¡Haz tu primera venta!");
                        } else {
                            tvTextoRecomendaciones.setText("Historial de ventas sincronizado correctamente.");
                        }

                        for (int i = 0; i < arrDias.length(); i++) {
                            JSONObject obj = arrDias.getJSONObject(i);
                            double totalDia = obj.getDouble("total");
                            String diaEn = obj.getString("dia_semana");

                            entradasDias.add(new BarEntry(i, (float) totalDia));
                            labelsDias.add(traducirDia(diaEn));
                        }

                        configurarGraficoBarras(entradasDias, labelsDias);

                        // ---------------------------------------------------------
                        // 3. GRÁFICO DE LÍNEAS: Curva Proyectada de Ventas
                        // ---------------------------------------------------------
                        ArrayList<Entry> entradasProyeccion = new ArrayList<>();
                        ArrayList<String> labelsProyeccion = new ArrayList<>();

                        String[] diasProyeccion = {"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"};
                        float[] valoresProyectados = {14200f, 14500f, 14892f, 15300f, 15100f, 15800f, 16200f};

                        for (int i = 0; i < diasProyeccion.length; i++) {
                            entradasProyeccion.add(new Entry(i, valoresProyectados[i]));
                            labelsProyeccion.add(diasProyeccion[i]);
                        }

                        configurarGraficoLineas(entradasProyeccion, labelsProyeccion);
                        // ---------------------------------------------------------

                    } catch (Exception e) {
                        e.printStackTrace();
                        tvTextoRecomendaciones.setText("Error leyendo las estadísticas.");
                    }
                },
                error -> {
                    tvTextoRecomendaciones.setText("Fallo de conexión con el servidor de ventas.");
                }
        );
        Volley.newRequestQueue(this).add(request);
    }

    // ==========================================================
    // CONFIGURACIÓN VISUAL DEL GRÁFICO DE BARRAS (Días)
    // ==========================================================
    private void configurarGraficoBarras(ArrayList<BarEntry> entradas, ArrayList<String> labels) {
        BarDataSet dataSet = new BarDataSet(entradas, "Ventas Diarias (S/)");
        dataSet.setColor(Color.parseColor("#E65100")); // Naranja
        dataSet.setValueTextSize(11);
        dataSet.setValueTextColor(Color.parseColor("#333333"));

        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.5f);
        graficoComercial.setData(barData);

        XAxis xAxis = graficoComercial.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));

        graficoComercial.getAxisLeft().setAxisMinimum(0f);
        graficoComercial.getAxisRight().setEnabled(false);
        graficoComercial.getDescription().setEnabled(false);
        graficoComercial.setFitBars(true);
        graficoComercial.animateY(1000);
        graficoComercial.invalidate();
    }

    // ==========================================================
    // CONFIGURACIÓN VISUAL DEL GRÁFICO DE LÍNEAS (Proyección)
    // ==========================================================
    private void configurarGraficoLineas(ArrayList<Entry> entradas, ArrayList<String> labels) {
        LineDataSet dataSet = new LineDataSet(entradas, "Proyección de Ventas (S/)");
        dataSet.setColor(Color.parseColor("#1A237E")); // Azul oscuro
        dataSet.setCircleColor(Color.parseColor("#0D47A1"));
        dataSet.setLineWidth(3f);
        dataSet.setCircleRadius(5);
        dataSet.setDrawFilled(true);
        dataSet.setFillColor(Color.parseColor("#BBDEFB"));
        dataSet.setValueTextSize(11);

        LineData lineData = new LineData(dataSet);
        lineChartPrediccion.setData(lineData);

        XAxis xAxis = lineChartPrediccion.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));

        lineChartPrediccion.getAxisRight().setEnabled(false);
        lineChartPrediccion.getDescription().setEnabled(false);
        lineChartPrediccion.animateX(1200);
        lineChartPrediccion.invalidate();
    }

    // ==========================================================
    // DICCIONARIOS DE TRADUCCIÓN INGLÉS A ESPAÑOL
    // ==========================================================
    private String traducirDia(String dia) {
        switch (dia) {
            case "Monday": return "Lun";
            case "Tuesday": return "Mar";
            case "Wednesday": return "Mié";
            case "Thursday": return "Jue";
            case "Friday": return "Vie";
            case "Saturday": return "Sáb";
            case "Sunday": return "Dom";
            default: return dia;
        }
    }

    private String traducirMes(String mes) {
        switch (mes) {
            case "January": return "Ene";
            case "February": return "Feb";
            case "March": return "Mar";
            case "April": return "Abr";
            case "May": return "May";
            case "June": return "Jun";
            case "July": return "Jul";
            case "August": return "Ago";
            case "September": return "Sep";
            case "October": return "Oct";
            case "November": return "Nov";
            case "December": return "Dic";
            default: return mes;
        }
    }
}