package activities;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.stockpyme.app.R; // Asegúrate de que este paquete sea el tuyo

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ReporteIAActivity extends AppCompatActivity {

    private Button btnGenerarAnalisis;
    private LineChart lineChartPrediccion;
    private TextView tvTextoRecomendaciones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reporte_ia);

        // 1. Enlazamos los componentes del XML
        btnGenerarAnalisis = findViewById(R.id.btnGenerarAnalisis);
        lineChartPrediccion = findViewById(R.id.lineChartPrediccion);
        tvTextoRecomendaciones = findViewById(R.id.tvTextoRecomendaciones);

        // 2. Configuramos el gráfico
        configurarGrafico();

        // 3. Acción del Botón
        btnGenerarAnalisis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mensaje temporal de carga
                tvTextoRecomendaciones.setText("Analizando tu negocio con IA... Esto tomará unos segundos 🧠");
                btnGenerarAnalisis.setEnabled(false); // Desactivamos el botón para evitar el spam
                btnGenerarAnalisis.setText("Pensando...");

                // Llamamos a nuestro servidor en Render
                solicitarDatosAlServidor();
            }
        });
    }

    private void configurarGrafico() {
        lineChartPrediccion.getDescription().setEnabled(false);
        lineChartPrediccion.getAxisRight().setEnabled(false);
        lineChartPrediccion.getXAxis().setDrawGridLines(false);
        lineChartPrediccion.setNoDataText("Aún no hay datos predictivos.");
    }

    private void solicitarDatosAlServidor() {
        // Tu URL real de Render
        String url = "https://agropets-stockpyme.onrender.com/api/inteligencia";

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String recomendaciones = response.getString("recomendaciones");
                            tvTextoRecomendaciones.setText(recomendaciones);

                            JSONArray prediccionesArray = response.getJSONArray("prediccionesGrafico");
                            ArrayList<Entry> entradasGrafico = new ArrayList<>();

                            for (int i = 0; i < prediccionesArray.length(); i++) {
                                // Forzamos la lectura segura de números
                                entradasGrafico.add(new Entry(i, (float) prediccionesArray.getDouble(i)));
                            }

                            LineDataSet dataSet = new LineDataSet(entradasGrafico, "Predicción de Ventas (S/)");
                            dataSet.setColor(Color.parseColor("#388E3C"));
                            dataSet.setLineWidth(3f);
                            dataSet.setCircleColor(Color.parseColor("#388E3C"));
                            dataSet.setValueTextSize(10f);

                            LineData lineData = new LineData(dataSet);
                            lineChartPrediccion.setData(lineData);
                            lineChartPrediccion.invalidate();

                            btnGenerarAnalisis.setEnabled(true);
                            btnGenerarAnalisis.setText("Generar Análisis IA");

                        } catch (JSONException e) {
                            tvTextoRecomendaciones.setText("Error armando los datos: " + e.getMessage());
                            btnGenerarAnalisis.setEnabled(true);
                            btnGenerarAnalisis.setText("Generar Análisis IA");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // AQUÍ ESTÁ EL SUERO DE LA VERDAD
                        String mensajeReal = "Error desconocido";
                        if (error.networkResponse != null) {
                            mensajeReal = "El servidor rechazó la conexión. Código: " + error.networkResponse.statusCode;
                        } else if (error instanceof com.android.volley.TimeoutError) {
                            mensajeReal = "Tiempo agotado (Timeout). La IA tardó demasiado en responder.";
                        } else {
                            mensajeReal = "Error de red o internet: " + error.toString();
                        }

                        tvTextoRecomendaciones.setText(mensajeReal);
                        btnGenerarAnalisis.setEnabled(true);
                        btnGenerarAnalisis.setText("Reintentar");
                    }
                }
        );

        // 👇 TRUCO VITAL 1: EVITAR QUE ANDROID USE ERRORES VIEJOS GUARDADOS 👇
        jsonObjectRequest.setShouldCache(false);

        // 👇 TRUCO VITAL 2: PACIENCIA EXTREMA 👇
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                25000, // 25 segundos de espera
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        queue.add(jsonObjectRequest);
    }
}