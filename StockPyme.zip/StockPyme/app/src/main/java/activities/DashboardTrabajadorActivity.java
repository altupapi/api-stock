package activities;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

public class DashboardTrabajadorActivity extends AppCompatActivity {
    LinearLayout containerStockProductos;
    TextView tvCantCriticos, tvSubtextCriticos;
    View btnVerInventario, btnRegistrarVenta, btnCerrarSesion; // Declaramos el botón aquí
    LinearLayout containerAlertas;

    private final String URL_API = "https://agropets-stockpyme.onrender.com/api/productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_trabajador);

        // 🌟 Enlazamos TODOS los componentes del XML, incluyendo el de ventas
        tvCantCriticos = findViewById(R.id.tvCantCriticos);
        tvSubtextCriticos = findViewById(R.id.tvSubtextCriticos);
        btnVerInventario = findViewById(R.id.btnVerInventario);
        btnRegistrarVenta = findViewById(R.id.btnRegistrarVenta); // Enlace del botón verde
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        containerAlertas = findViewById(R.id.containerAlertas);
        containerStockProductos = findViewById(R.id.containerStockProductos);

        cargarReporteStock();
        Button btnRegistrarEntrada = findViewById(R.id.btnRegistrarEntrada);

        btnRegistrarEntrada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Abre la pantalla que acabamos de corregir
                Intent intent = new Intent(DashboardTrabajadorActivity.this, IngresoMercaderiaActivity.class);
                startActivity(intent);
            }
        });
        // 📦 Acción: Ir a ver el Inventario completo
        if (btnVerInventario != null) {
            btnVerInventario.setOnClickListener(v -> {
                Intent intent = new Intent(DashboardTrabajadorActivity.this, InventarioActivity.class);
                startActivity(intent);
            });
        }

        // 🛒 Acción: Registrar Venta / Salida (¡SOLUCIÓN AQUÍ!)
        if (btnRegistrarVenta != null) {
            btnRegistrarVenta.setOnClickListener(v -> {
                Intent intent = new Intent(DashboardTrabajadorActivity.this, VentasActivity.class);
                startActivity(intent);
            });
        }

        // 🚪 Acción: Cerrar Sesión
        if (btnCerrarSesion != null) {
            btnCerrarSesion.setOnClickListener(v -> {
                Intent intent = new Intent(DashboardTrabajadorActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarReporteStock();
    }

    private void cargarReporteStock() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, URL_API, null,
                response -> {
                    try {
                        if (containerAlertas != null) containerAlertas.removeAllViews();
                        if (containerStockProductos != null) containerStockProductos.removeAllViews();

                        int articulosCriticos = 0;

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject producto = response.getJSONObject(i);
                            String nombre = producto.getString("nombre");
                            int cantidad = producto.getInt("cantidad");
                            String sku = "SKU: 7750" + (100000 + producto.optInt("id", i));

                            agregarFilaProgresoStock(nombre, cantidad);

                            if (cantidad <= 5) {
                                articulosCriticos++;
                                agregarTarjetaAlertaDinámica(nombre, cantidad, sku);
                            }
                        }

                        if (tvCantCriticos != null) {
                            tvCantCriticos.setText(String.valueOf(articulosCriticos));
                        }

                        if (tvSubtextCriticos != null) {
                            if (articulosCriticos > 0) {
                                tvSubtextCriticos.setText("Artículos requieren reposición");
                            } else {
                                tvSubtextCriticos.setText("Todo el stock en orden");

                                if (containerAlertas != null) {
                                    TextView tvVacio = new TextView(this);
                                    tvVacio.setText("🎉 ¡Todo al día! No hay quiebres de stock.");
                                    tvVacio.setPadding(20, 40, 20, 40);
                                    tvVacio.setGravity(android.view.Gravity.CENTER);
                                    containerAlertas.addView(tvVacio);
                                }
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    if (tvCantCriticos != null) tvCantCriticos.setText("!");
                    if (tvSubtextCriticos != null) tvSubtextCriticos.setText("Sin conexión");
                }
        );

        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void agregarFilaProgresoStock(String nombre, int cantidad) {
        if (containerStockProductos == null) return;

        View itemView = getLayoutInflater().inflate(R.layout.item_stock_progreso, containerStockProductos, false);

        TextView tvNombre = itemView.findViewById(R.id.tvNombreProductoProgreso);
        TextView tvValores = itemView.findViewById(R.id.tvValoresStock);
        ProgressBar progressStock = itemView.findViewById(R.id.progressStock);

        if (tvNombre != null) tvNombre.setText(nombre);

        int stockMinimoSugerido = 20;
        if (tvValores != null) tvValores.setText(cantidad + " / " + stockMinimoSugerido);

        if (progressStock != null) {
            int maxBarra = Math.max(stockMinimoSugerido, cantidad);
            progressStock.setMax(maxBarra);
            progressStock.setProgress(cantidad);

            if (cantidad <= 5) {
                if (tvValores != null) tvValores.setTextColor(Color.parseColor("#C62828"));
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#C62828")));
                }
            } else {
                if (tvValores != null) tvValores.setTextColor(Color.parseColor("#1A1A1A"));
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    progressStock.setProgressTintList(ColorStateList.valueOf(Color.parseColor("#2E7D32")));
                }
            }
        }

        runOnUiThread(() -> containerStockProductos.addView(itemView));
    }

    private void agregarTarjetaAlertaDinámica(String nombre, int cantidad, String sku) {
        if (containerAlertas == null) return;

        View cardView = getLayoutInflater().inflate(R.layout.item_alerta_stock, containerAlertas, false);

        View indicatorBar = cardView.findViewById(R.id.indicatorBar);
        TextView tvNombreProd = cardView.findViewById(R.id.tvNombreProd);
        TextView tvSkuProd = cardView.findViewById(R.id.tvSkuProd);
        TextView tvCantUnidades = cardView.findViewById(R.id.tvCantUnidades);
        TextView tvBadgeEstado = cardView.findViewById(R.id.tvBadgeEstado);

        if (tvNombreProd != null) tvNombreProd.setText(nombre);
        if (tvSkuProd != null) tvSkuProd.setText(sku);
        if (tvCantUnidades != null) tvCantUnidades.setText(cantidad + "\nUNIDADES");

        if (tvBadgeEstado != null && indicatorBar != null) {
            if (cantidad == 0) {
                indicatorBar.setBackgroundColor(Color.parseColor("#C62828"));
                tvBadgeEstado.setText("Agotado");
                tvBadgeEstado.setTextColor(Color.parseColor("#C62828"));
                tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_rojo);
            } else {
                indicatorBar.setBackgroundColor(Color.parseColor("#EF6C00"));
                tvBadgeEstado.setText("Stock Bajo");
                tvBadgeEstado.setTextColor(Color.parseColor("#E65100"));
                tvBadgeEstado.setBackgroundResource(R.drawable.bg_badge_naranja);
            }
        }

        cardView.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardTrabajadorActivity.this, InventarioActivity.class);
            startActivity(intent);
        });

        containerAlertas.addView(cardView);
    }
}