package activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import com.stockpyme.app.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class VentasActivity extends AppCompatActivity {

    Spinner spinnerCategorias, spinnerProductos;
    EditText etCantidadVenta;
    TextView tvTotalVentaGeneral;
    LinearLayout containerItemsCarrito;

    // Listas para almacenar la información cruda del servidor
    List<String> listaCategoriasNames = new ArrayList<>();
    List<JSONObject> todosLosProductos = new ArrayList<>();
    List<JSONObject> productosFiltrados = new ArrayList<>();

    // Lista para armar el carrito que se mandará a Node.js
    List<JSONObject> carritoVenta = new ArrayList<>();
    double totalGeneral = 0.0;
    private Button btnEscanearCodigo;
    private final String URL_CATEGORIAS = "https://agropets-stockpyme.onrender.com/api/categorias";
    private final String URL_PRODUCTOS = "https://agropets-stockpyme.onrender.com/api/productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventas);

        // Enlaces con la interfaz gráfica
        spinnerCategorias = findViewById(R.id.spinnerCategorias);
        spinnerProductos = findViewById(R.id.spinnerProductos);
        etCantidadVenta = findViewById(R.id.etCantidadVenta);
        tvTotalVentaGeneral = findViewById(R.id.tvTotalVentaGeneral);
        containerItemsCarrito = findViewById(R.id.containerItemsCarrito);
        btnEscanearCodigo = findViewById(R.id.btnEscanearCodigo);

        // 📷 Botón que abre la cámara de ZXing
        btnEscanearCodigo.setOnClickListener(v -> {
            ScanOptions options = new ScanOptions();
            options.setPrompt("Apunta al código de barras del producto");
            options.setBeepEnabled(true);
            options.setOrientationLocked(false);
            options.setCaptureActivity(com.journeyapps.barcodescanner.CaptureActivity.class);
            barcodeLauncher.launch(options);
        });

        // 📥 1. Descargar todos los productos e inicializar flujos
        descargarDatosIniciales();

        // 🎯 2. Listener: Cuando cambie el Spinner de Categorías, se filtra el de Productos
        spinnerCategorias.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String categoriaSeleccionada = listaCategoriasNames.get(position);
                actualizarSpinnerProductos(categoriaSeleccionada);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // ➕ Botón Añadir al Carrito
        findViewById(R.id.btnAgregarAlCarrito).setOnClickListener(v -> agregarProductoAlCarrito());

        // 🔀 Botón para ir a la pantalla de Pago
        findViewById(R.id.btnFinalizarVenta).setOnClickListener(v -> abrirPantallaDePago());
    }

    // =================================================================================
    // 📸 LÓGICA DEL ESCÁNER DE CÓDIGOS DE BARRAS
    // =================================================================================

    private final androidx.activity.result.ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if(result.getContents() == null) {
                    Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show();
                } else {
                    String codigoEscaneado = result.getContents();
                    buscarProductoPorCodigoQR(codigoEscaneado);
                }
            });

    private void buscarProductoPorCodigoQR(String codigoEscaneado) {
        boolean encontrado = false;

        if(spinnerCategorias.getCount() > 0) {
            spinnerCategorias.setSelection(0);
            actualizarSpinnerProductos("Todos");
        }

        for (int i = 0; i < productosFiltrados.size(); i++) {
            JSONObject prod = productosFiltrados.get(i);
            String codigoBD = prod.optString("id", "");

            if (codigoBD.equals(codigoEscaneado)) {
                spinnerProductos.setSelection(i);
                etCantidadVenta.setText("1");
                encontrado = true;
                Toast.makeText(this, "✅ Producto seleccionado: " + prod.optString("nombre"), Toast.LENGTH_SHORT).show();
                break;
            }
        }

        if (!encontrado) {
            Toast.makeText(this, "❌ Código no registrado: " + codigoEscaneado, Toast.LENGTH_LONG).show();
        }
    }

    // =================================================================================
    // MÉTODOS DE LA API Y CARRITO
    // =================================================================================

    private void descargarDatosIniciales() {
        JsonArrayRequest prodRequest = new JsonArrayRequest(Request.Method.GET, URL_PRODUCTOS, null,
                response -> {
                    try {
                        todosLosProductos.clear();
                        for (int i = 0; i < response.length(); i++) {
                            todosLosProductos.add(response.getJSONObject(i));
                        }
                        descargarCategorias();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error de red al traer productos", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(prodRequest);
    }

    private void descargarCategorias() {
        JsonArrayRequest catRequest = new JsonArrayRequest(Request.Method.GET, URL_CATEGORIAS, null,
                response -> {
                    listaCategoriasNames.clear();
                    listaCategoriasNames.add("Todos");

                    for (int i = 0; i < response.length(); i++) {
                        try {
                            listaCategoriasNames.add(response.getString(i));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    ArrayAdapter<String> adapterCat = new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_item, listaCategoriasNames);
                    adapterCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerCategorias.setAdapter(adapterCat);
                },
                error -> Log.e("API_ERR", "Error trayendo categorías: " + error.toString())
        );
        Volley.newRequestQueue(this).add(catRequest);
    }

    private void actualizarSpinnerProductos(String categoria) {
        productosFiltrados.clear();
        List<String> nombresProductosAMostrar = new ArrayList<>();

        for (JSONObject prod : todosLosProductos) {
            String catProd = prod.optString("categoria", "General");
            if (categoria.equals("Todos") || catProd.equalsIgnoreCase(categoria)) {
                productosFiltrados.add(prod);

                String infoVisual = prod.optString("nombre") + " (S/ " + prod.optDouble("precio", 0.0) + ")";
                nombresProductosAMostrar.add(infoVisual);
            }
        }

        ArrayAdapter<String> adapterProd = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, nombresProductosAMostrar);
        adapterProd.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProductos.setAdapter(adapterProd);
    }

    private void agregarProductoAlCarrito() {
        if (productosFiltrados.isEmpty()) return;

        int indexSeleccionado = spinnerProductos.getSelectedItemPosition();
        if (indexSeleccionado < 0) return;

        JSONObject prodSeleccionado = productosFiltrados.get(indexSeleccionado);
        String cantStr = etCantidadVenta.getText().toString().trim();
        int cantidad = cantStr.isEmpty() ? 1 : Integer.parseInt(cantStr);

        if (cantidad <= 0) {
            Toast.makeText(this, "Ingresa una cantidad válida", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double precio = prodSeleccionado.getDouble("precio");
            String nombre = prodSeleccionado.getString("nombre");
            int idProd = prodSeleccionado.getInt("id");

            // 1. Guardamos el objeto lógicamente en la lista del carrito
            JSONObject itemCarrito = new JSONObject();
            itemCarrito.put("producto_id", idProd);
            itemCarrito.put("nombre", nombre);
            itemCarrito.put("cantidad", cantidad);
            itemCarrito.put("precio_unitario", precio);

            carritoVenta.add(itemCarrito);

            // =========================================================================
            // 🔨 MAGIA AQUÍ: INFLACIÓN DINÁMICA DE TU TARJETA (item_carrito.xml)
            // =========================================================================
            LayoutInflater inflater = LayoutInflater.from(this);
            View itemView = inflater.inflate(R.layout.item_carrito, containerItemsCarrito, false);

            // Enlazamos las vistas internas de la tarjeta
            TextView tvNombre = itemView.findViewById(R.id.tvNombreItemCarrito);
            TextView tvDetalle = itemView.findViewById(R.id.tvDetalleItemCarrito);
            TextView tvSubtotal = itemView.findViewById(R.id.tvSubtotalItemCarrito);
            ImageButton btnEliminar = itemView.findViewById(R.id.btnEliminarItemCarrito);

            // Seteamos los valores correspondientes
            tvNombre.setText(nombre);
            tvDetalle.setText("Cant: " + cantidad + " x S/ " + String.format(Locale.US, "%.2f", precio));

            double subtotal = precio * cantidad;
            tvSubtotal.setText("S/ " + String.format(Locale.US, "%.2f", subtotal));

            // 🛑 BOTÓN ELIMINAR: Configuración del clic para remover el ítem
            btnEliminar.setOnClickListener(v -> {
                // A. Remover de la lista lógica
                carritoVenta.remove(itemCarrito);

                // B. Remover visualmente del Layout contenedor
                containerItemsCarrito.removeView(itemView);

                // C. Restar del total general y actualizar UI
                totalGeneral -= subtotal;
                tvTotalVentaGeneral.setText("S/ " + String.format(Locale.US, "%.2f", totalGeneral));

                Toast.makeText(this, "🗑️ Se quitó " + nombre, Toast.LENGTH_SHORT).show();
            });

            // Agregamos el diseño inflado al contenedor en la pantalla
            containerItemsCarrito.addView(itemView);

            // 2. Sumamos al total general y actualizamos el texto verde
            totalGeneral += subtotal;
            tvTotalVentaGeneral.setText("S/ " + String.format(Locale.US, "%.2f", totalGeneral));

            etCantidadVenta.setText("1");

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void abrirPantallaDePago() {
        if (carritoVenta.isEmpty()) {
            Toast.makeText(this, "⚠️ El carrito de compras está vacío", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONArray detallesArray = new JSONArray();
        for (JSONObject item : carritoVenta) {
            detallesArray.put(item);
        }

        Intent intent = new Intent(VentasActivity.this, PagoVentaActivity.class);
        intent.putExtra("carrito_productos", detallesArray.toString());
        intent.putExtra("monto_total", totalGeneral);
        startActivity(intent);
    }
}