package activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class ProductosActivity extends AppCompatActivity {

    EditText etNombre, etCantidad, etPrecio;
    Spinner spCategoria;
    Button btnVolver, btnGuardar;
    com.google.android.material.floatingactionbutton.FloatingActionButton btnAbrirFormulario;
    ListView listaProductos;

    ArrayList<String> lista;
    ArrayList<Integer> ids;
    ArrayAdapter<String> adapter;

    private final String URL_API = "https://agropets-stockpyme.onrender.com/api/productos";
    private final String[] CATEGORIAS = {"Aguas", "Gaseosas", "Cervezas", "Dulces y Galletas", "Snacks", "Abarrotes", "Limpieza"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);

        // Enlazamos los componentes de la pantalla principal limpia
        listaProductos = findViewById(R.id.listaProductos);
        btnVolver = findViewById(R.id.btnVolver);
        btnAbrirFormulario = findViewById(R.id.btnAbrirFormulario);

        // Cargar los productos desde Clever Cloud al iniciar
        mostrarProductos();

        btnVolver.setOnClickListener(v -> finish());

        // ? Al presionar el "+" se abre la hermosa hoja inferior (Bottom Sheet)
        btnAbrirFormulario.setOnClickListener(v -> abrirFormularioModal());

        listaProductos.setOnItemClickListener((parent, view, position, id) -> {
            editarProducto(ids.get(position));
        });

        listaProductos.setOnItemLongClickListener((parent, view, position, id) -> {
            int idProducto = ids.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Eliminar")
                    .setMessage("Deseas eliminar este producto?")
                    .setPositiveButton("Si", (dialog, which) -> eliminarProducto(idProducto))
                    .setNegativeButton("No", null)
                    .show();
            return true;
        });
    }


    private void abrirFormularioModal() {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog =
                new com.google.android.material.bottomsheet.BottomSheetDialog(this);

        View view = getLayoutInflater().inflate(R.layout.item_formulario_modal, null);


        etNombre = view.findViewById(R.id.etNombre);
        etCantidad = view.findViewById(R.id.etCantidad);
        etPrecio = view.findViewById(R.id.etPrecio);
        spCategoria = view.findViewById(R.id.spCategoria);
        btnGuardar = view.findViewById(R.id.btnGuardar);


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, CATEGORIAS);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCategoria.setAdapter(spinnerAdapter);


        btnGuardar.setOnClickListener(v -> {
            guardarProducto(dialog);
        });

        dialog.setContentView(view);
        dialog.show();
    }

    private void guardarProducto(com.google.android.material.bottomsheet.BottomSheetDialog dialog) {
        String nombre = etNombre.getText().toString().trim();
        String cantidadStr = etCantidad.getText().toString().trim();
        String precioStr = etPrecio.getText().toString().trim();

        if (nombre.isEmpty() || cantidadStr.isEmpty() || precioStr.isEmpty()) {
            Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        String categoria = spCategoria.getSelectedItem().toString();

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("nombre", nombre);
            jsonBody.put("cantidad", Integer.parseInt(cantidadStr));
            jsonBody.put("precio", Double.parseDouble(precioStr));
            jsonBody.put("categoria", categoria);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        com.android.volley.toolbox.JsonObjectRequest jsonObjectRequest = new com.android.volley.toolbox.JsonObjectRequest(
                com.android.volley.Request.Method.POST,
                URL_API,
                jsonBody,
                response -> {
                    // Quitamos caracteres especiales conflictivos del Toast
                    Toast.makeText(ProductosActivity.this, "Producto guardado con exito", Toast.LENGTH_SHORT).show();

                    dialog.dismiss();
                    mostrarProductos();
                },
                error -> {
                    error.printStackTrace();
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String errorOculto = new String(error.networkResponse.data, "UTF-8");
                            android.util.Log.e("ERROR_REAL_SERVIDOR", errorOculto);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(ProductosActivity.this, "Error al guardar producto", Toast.LENGTH_SHORT).show();
                }
        );

        Volley.newRequestQueue(this).add(jsonObjectRequest);
    }

    private void mostrarProductos() {
        lista = new ArrayList<>();
        ids = new ArrayList<>();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET, URL_API, null,
                response -> {
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject producto = response.getJSONObject(i);
                            int id = producto.getInt("id");
                            String nombre = producto.getString("nombre");
                            int stock = producto.getInt("cantidad");
                            double precio = producto.getDouble("precio");
                            String categoria = producto.optString("categoria", "General");

                            ids.add(id);

                            String fila = nombre + " [" + categoria + "] - Stock: " + stock + " - S/ " + precio;
                            if (stock < 5) {
                                fila = "[Stock bajo] " + fila;
                            }
                            lista.add(fila);
                        }

                        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, lista);
                        listaProductos.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error al obtener productos de la nube", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }

    private void eliminarProducto(int id) {
        String urlEliminar = URL_API + "/" + id;

        StringRequest stringRequest = new StringRequest(
                Request.Method.DELETE, urlEliminar,
                response -> {
                    Toast.makeText(this, "Producto eliminado", Toast.LENGTH_SHORT).show();
                    mostrarProductos();
                },
                error -> Toast.makeText(this, "Error al eliminar producto", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private void editarProducto(int id) {
        EditText nuevoNombre = new EditText(this);
        nuevoNombre.setHint("Nuevo nombre");

        EditText nuevaCantidad = new EditText(this);
        nuevaCantidad.setHint("Nueva cantidad");

        EditText nuevoPrecio = new EditText(this);
        nuevoPrecio.setHint("Nuevo precio");

        Spinner nuevaCategoria = new Spinner(this);
        ArrayAdapter<String> editSpinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, CATEGORIAS);
        editSpinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nuevaCategoria.setAdapter(editSpinnerAdapter);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 40, 50, 40);
        layout.addView(nuevoNombre);
        layout.addView(nuevaCantidad);
        layout.addView(nuevoPrecio);
        layout.addView(nuevaCategoria);

        new AlertDialog.Builder(this)
                .setTitle("Editar Producto")
                .setView(layout)
                .setPositiveButton("Guardar", (dialog, which) -> {
                    String urlEditar = URL_API + "/" + id;
                    final String requestBody;
                    try {
                        JSONObject jsonBody = new JSONObject();
                        jsonBody.put("nombre", nuevoNombre.getText().toString());
                        jsonBody.put("cantidad", Integer.parseInt(nuevaCantidad.getText().toString()));
                        jsonBody.put("precio", Double.parseDouble(nuevoPrecio.getText().toString()));
                        jsonBody.put("categoria", nuevaCategoria.getSelectedItem().toString());
                        requestBody = jsonBody.toString();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        return;
                    }

                    StringRequest stringRequest = new StringRequest(
                            Request.Method.PUT, urlEditar,
                            response -> {
                                Toast.makeText(this, "Producto actualizado", Toast.LENGTH_SHORT).show();
                                mostrarProductos();
                            },
                            error -> Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show()
                    ) {
                        @Override
                        public String getBodyContentType() {
                            return "application/json; charset=utf-8";
                        }
                        @Override
                        public byte[] getBody() {
                            try {
                                return requestBody.getBytes("utf-8");
                            } catch (UnsupportedEncodingException uee) {
                                return null;
                            }
                        }
                    };
                    Volley.newRequestQueue(this).add(stringRequest);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}