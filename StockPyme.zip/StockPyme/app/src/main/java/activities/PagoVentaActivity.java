package activities; // Mantengo tu paquete original

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

// 🟢 IMPORTACIONES CORREGIDAS PARA MATERIAL DESIGN
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.stockpyme.app.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;

public class PagoVentaActivity extends AppCompatActivity {

    private RadioGroup rgMetodoPago;

    // 🟢 CORRECCIÓN APLICADA: Ahora es MaterialCardView
    private MaterialCardView layoutQrYape;

    // 🟢 CORRECCIÓN APLICADA: Ahora son TextInputEditText
    private TextInputEditText etNombreCliente, etTelefonoCliente;

    // 🟢 CORRECCIÓN APLICADA: Ahora es MaterialButton
    private MaterialButton btnFinalizarVenta;

    private RequestQueue requestQueue;
    private String carritoJsonString;
    private double montoTotal = 0.0;

    private final String BASE_URL = "https://agropets-stockpyme.onrender.com/api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pago_venta);

        // Enlace de vistas
        rgMetodoPago = findViewById(R.id.rgMetodoPago);
        layoutQrYape = findViewById(R.id.layoutQrYape);
        etNombreCliente = findViewById(R.id.etNombreCliente);
        etTelefonoCliente = findViewById(R.id.etTelefonoCliente);
        btnFinalizarVenta = findViewById(R.id.btnFinalizarVenta);

        requestQueue = Volley.newRequestQueue(this);

        if (getIntent().hasExtra("carrito_productos")) {
            carritoJsonString = getIntent().getStringExtra("carrito_productos");
        }
        if (getIntent().hasExtra("monto_total")) {
            montoTotal = getIntent().getDoubleExtra("monto_total", 0.0);
        }

        rgMetodoPago.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbYape) {
                layoutQrYape.setVisibility(View.VISIBLE);
                Toast.makeText(this, "📱 Muestra el QR al cliente", Toast.LENGTH_SHORT).show();
            } else {
                layoutQrYape.setVisibility(View.GONE);
            }
        });

        btnFinalizarVenta.setOnClickListener(v -> procesarVentaFinal());
    }

    private void procesarVentaFinal() {
        String nombre = etNombreCliente.getText() != null ? etNombreCliente.getText().toString().trim() : "";
        String telefono = etTelefonoCliente.getText() != null ? etTelefonoCliente.getText().toString().trim() : "";

        String metodoPago = (rgMetodoPago.getCheckedRadioButtonId() == R.id.rbYape) ? "Yape" : "Efectivo";

        if (nombre.isEmpty() || telefono.isEmpty()) {
            Toast.makeText(this, "⚠️ Completa los datos del cliente", Toast.LENGTH_SHORT).show();
            return;
        }

        // Desactivar botón para que no le des doble clic sin querer
        btnFinalizarVenta.setEnabled(false);
        Toast.makeText(this, "⏳ Procesando venta...", Toast.LENGTH_SHORT).show();

        try {
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("metodo_pago", metodoPago);
            jsonBody.put("cliente_nombre", nombre);
            jsonBody.put("cliente_telefono", telefono);
            jsonBody.put("monto_total", montoTotal);

            if (carritoJsonString != null) {
                JSONArray detallesArray = new JSONArray(carritoJsonString);
                jsonBody.put("detalles", detallesArray);
            } else {
                Toast.makeText(this, "❌ El carrito está vacío", Toast.LENGTH_SHORT).show();
                btnFinalizarVenta.setEnabled(true);
                return;
            }

            String urlPost = BASE_URL + "ventas";

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlPost, jsonBody,
                    response -> {
                        try {
                            // 1. Extraemos el link
                            String urlPdfBoleta = response.getString("pdf_url");

                            Toast.makeText(this, "✅ Venta lista. Abriendo WhatsApp...", Toast.LENGTH_LONG).show();

                            // 2. Disparamos WhatsApp INMEDIATAMENTE
                            enviarBoletaWhatsApp(telefono, nombre, urlPdfBoleta);

                            // 3. EL TRUCO: Le damos 2.5 segundos de pausa antes de volver al menú
                            // para que WhatsApp tenga vía libre de abrirse sin ser interrumpido.
                            new android.os.Handler().postDelayed(() -> {
                                irAPantallaPrincipal();
                            }, 2500);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            // Si ves este error, tu servidor Node.js no está enviando el "pdf_url"
                            Toast.makeText(this, "⚠️ Error: El servidor no devolvió el link del PDF. ¿Actualizaste Render?", Toast.LENGTH_LONG).show();
                            btnFinalizarVenta.setEnabled(true);
                        }
                    },
                    error -> {
                        if (error.networkResponse != null && (error.networkResponse.statusCode == 200 || error.networkResponse.statusCode == 201)) {
                            Toast.makeText(this, "🎉 Venta registrada, pero falló la lectura del PDF", Toast.LENGTH_LONG).show();
                            irAPantallaPrincipal();
                        } else {
                            Log.e("API_VENTA_ERR", error.toString());
                            Toast.makeText(this, "❌ Error de conexión al guardar la venta", Toast.LENGTH_SHORT).show();
                            btnFinalizarVenta.setEnabled(true);
                        }
                    }
            );

            requestQueue.add(request);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error local armando el pedido", Toast.LENGTH_SHORT).show();
            btnFinalizarVenta.setEnabled(true);
        }
    }

    // MÉTODO QUE FUERZA ABRIR LA APP DE WHATSAPP DIRECTAMENTE
    private void enviarBoletaWhatsApp(String telefono, String nombreCliente, String urlPdf) {
        try {
            String mensaje = "📄 *BOLETA ELECTRÓNICA - AGROPETS*\n\n" +
                    "¡Hola " + nombreCliente + "! Muchas gracias por tu compra. ✨\n\n" +
                    "Puedes visualizar y descargar tu boleta digital aquí:\n" +
                    urlPdf + "\n\n" +
                    "¡Que tengas un excelente día!";

            // Usamos whatsapp:// en lugar de https:// para saltarnos el navegador e ir directo a la App
            String uri = "whatsapp://send?phone=51" + telefono + "&text=" + URLEncoder.encode(mensaje, "UTF-8");

            Intent intentWsp = new Intent(Intent.ACTION_VIEW);
            intentWsp.setData(Uri.parse(uri));
            startActivity(intentWsp);

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "⚠️ No se pudo abrir WhatsApp. ¿Está instalado?", Toast.LENGTH_LONG).show();
        }
    }

    private void irAPantallaPrincipal() {
        Intent intent = new Intent(PagoVentaActivity.this, DashboardTrabajadorActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}